package com.example.admin.teachforindia;

import android.app.ProgressDialog;
import android.content.Intent;
import android.icu.lang.UCharacterEnums;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v4.text.TextUtilsCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.ui.auth.AuthUI;
import com.firebase.ui.auth.AuthUI.SignInIntentBuilder;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;import java.security.ProtectionDomain;
import static com.google.firebase.auth.FirebaseAuth.*;

public class MainActivity extends AppCompatActivity{

    private DatabaseReference mDatabase;
    private EditText name;
    private EditText phone;
    private EditText email;
    private EditText message;
    private EditText locality;
    private Button submitBtn;
    int userId=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mDatabase = FirebaseDatabase.getInstance().getReference();
        final DatabaseReference uref= mDatabase.child(String.valueOf(name));

        name = (EditText) findViewById(R.id.name);
        email = (EditText) findViewById(R.id.email);
        phone = (EditText) findViewById(R.id.phone);
        locality = (EditText) findViewById(R.id.locality);
        message = (EditText) findViewById(R.id.message);
        submitBtn = (Button) findViewById(R.id.submit);

        submitBtn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                uref.setValue(name);


            }
        });

    }
}
